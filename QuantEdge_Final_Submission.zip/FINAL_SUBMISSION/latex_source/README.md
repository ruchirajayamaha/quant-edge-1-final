# LaTeX report sources

These sources produce the submitted memo, tear sheet, recommendation and printable review pack.
`results/final/reference.json` and the frozen CSVs are the only numerical authority. Numbers in
the documents come from generated macros and tables, so do not type a result into the `.tex` files.

| Source | Output | Page rule |
|---|---|---|
| `main.tex` | `FINAL_SUBMISSION/01_Investment_Memo.pdf` | 7 to 15 pages |
| `tear_sheet.tex` | `FINAL_SUBMISSION/02_Executive_Tear_Sheet.pdf` | exactly 1 |
| `recommendation.tex` | `FINAL_SUBMISSION/supporting/Recommendation.pdf` | exactly 1 |
| `human_review_pack.tex` | `handoff/human_review_pack/human_review_pack.pdf` | 2 to 5, outside the memo budget |

Style is in `style/quantedge.sty`; references are
in `references.bib`. Everything under `generated/` is rebuilt from the frozen results, so edit the
generator and not the output.

## Toolchain used

- Engine: XeLaTeX, `MiKTeX-XeTeX 4.16 (MiKTeX 25.12)`, writing PDF through MiKTeX-dvipdfmx 20250413.
- Bibliography: BibTeX with `plainnat`, through `natbib`.
- Fonts: Libertinus Serif, Sans, Math and Mono (MiKTeX package `libertinus-fonts`), loaded by file.
- Python: `pip install -r requirements.txt -r requirements-render.txt`.

Run `xelatex --version` to record the exact version on another machine. Page breaks can shift with a
different TeX distribution, and the build fails if a page limit is broken.

## Build

Authoritative command, from the repository root:

```bash
python scripts/build_reports.py
```

It exports the figures, generates macros, tables and the review pack, runs XeLaTeX and BibTeX in
`tmp/report_build`, fails on an undefined reference, missing glyph, or overfull box above 2 pt, checks
page limits and only then publishes. Other forms:

```bash
python scripts/build_reports.py --no-publish
```

```bash
python scripts/build_reports.py --tex-only
```

The script finds TeX on `PATH`. Set `QE_TEX_BIN` to the folder holding `xelatex` if it is elsewhere.
On the development machine that folder is `D:\QuantEdgeTools\miktex\miktex\bin\x64`.

## Compile this folder on its own

The generated inputs are included, so a copy of this folder compiles without the repository or Python:

```bash
xelatex main.tex
```

```bash
bibtex main
```

Then run `xelatex main.tex` twice more. The tear sheet, recommendation and review pack need only XeLaTeX,
run twice. `FINAL_SUBMISSION/latex_source/` is such a copy, written by `scripts/package_submission.py`.

## After a build

```bash
python audit/presentation_review/verify_presentation.py
```

```bash
python scripts/render_pdf_pages.py FINAL_SUBMISSION/01_Investment_Memo.pdf tmp/pdf_review 1.6
```

Passing the build does not prove the pages read well. Look at every rendered page.

`scripts/build_submission_pdfs.py` is the superseded ReportLab builder. It refuses to run without
`--legacy-reportlab`, and it then writes only to `output/legacy_reportlab/`.

The dashboard needs none of this. It only serves the published PDFs.

## Named corrected review draft

`python scripts/build_named_review.py` recomputes the reference values and compiles
`review_nisal_induwara.tex` into
`FINAL_SUBMISSION/supporting/Human_Review_Nisal_Induwara_DRAFT.pdf` (three pages).
It uses the same TeX environment/font setup as the main reports. The reviewer name
and typed signature were supplied by the user; the document explicitly awaits
confirmation of actual review methods, date, findings and decision. It does not
replace the blank review pack or certify independent human validation.
